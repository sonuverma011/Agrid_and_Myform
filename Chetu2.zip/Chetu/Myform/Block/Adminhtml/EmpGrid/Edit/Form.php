<?php

namespace Chetu\Myform\Block\Adminhtml\EmpGrid\Edit;

//  Adminhtml Add New Row Form.

class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Chetu\Myform\Model\Status $options,
        array $data = []
    ) {
        $this->_options = $options;
        $this->_wysiwygConfig = $wysiwygConfig;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('emp_data');
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form',
                            'enctype' => 'multipart/form-data',
                            'action' => $this->getData('action'),
                            'method' => 'post'
                        ]
            ]
        );

        $form->setHtmlIdPrefix('chetumyform_');
        if ($model->getEmployeeId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Edit Row Data'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('employee_id', 'hidden', ['name' => 'employee_id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Add Row Data'), 'class' => 'fieldset-wide']
            );
        }

        $fieldset->addField(
            'employee_name',
            'text',
            [
                'name' => 'employee_name',
                'label' => __('Employee Name'),
                'id' => 'employee_id',
                'title' => __('Employee Name'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        // $wysiwygConfig = $this->_wysiwygConfig->getConfig(['tab_id' => $this->getTabId()]);

        $fieldset->addField(
            'employee_age',
            'text',
            [
                'name' => 'employee_age',
                'label' => __('Employee Age'),
                'id' => 'employee_age',
                'title' => __('Employee Age'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );

        $fieldset->addField(
            'employee_phone',
            'text',
            [
                'name' => 'employee_phone',
                'label' => __('Employee Phone'),
                'id' => 'employee_phone',
                'title' => __('Employee Phone'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'employee_gender',
            'select',
            [
                'name' => 'employee_gender',
                'label' => __('Employee Gender'),
                'id' => 'employee_gender',
                'title' => __('Employee Gender'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}