<?php

namespace Chetu\Myform\Model;

use \Magento\Framework\Model\AbstractModel;

use \Magento\Framework\DataObject\IdentityInterface;

use \Chetu\Myform\Api\Data\DisplayInterface;

class EmpGrid extends \Magento\Framework\Model\AbstractModel
{
	
    const EMPLOYEE_ID             = 'employee_id';
    const EMPLOYEE_NAME           = 'employee_name';
    const EMPLOYEE_AGE            = 'employee_age';
    const EMPLOYEE_PHONE          = 'employee_phone';
    const EMPLOYEE_GENDER         = 'employee_gender';

	public function _construct()
	{
		$this->_init('Chetu\Myform\Model\ResourceModel\EmpGrid');
	}

	public function getEmployeeId()
    {
        return $this->getData(self::EMPLOYEE_ID);
    }
	public function getEmployeeName()
    {
        return $this->getData(self::EMPLOYEE_NAME);
    }
    public function getEmployeeAge()
    {
        return $this->getData(self::EMPLOYEE_AGE);
    }
	public function getEmployeePhone()
    {
        return $this->getData(self::EMPLOYEE_PHONE);
    }
	public function getEmployeeGender()
    {
        return $this->getData(self::EMPLOYEE_GENDER);
    }
}