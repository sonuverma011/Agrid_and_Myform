<?php
namespace Chetu\Myform\Api\Data;

interface DisplayInterface
{
    /**#@+
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const EMPLOYEE_ID             = 'employee_id';
    const EMPLOYEE_NAME           = 'employee_name';
    const EMPLOYEE_AGE            = 'employee_age';
    const EMPLOYEE_PHONE          = 'employee_phone';
    const EMPLOYEE_GENDER         = 'employee_gender';
    /**#@-*/

    public function getEmployeeId();

    public function getEmployeeName();

    public function getEmployeeAge();

    public function getEmployeePhone();

    public function getEmployeeGender();

    /**
     * Set Id
     *
     * @param string $employeeid
     * @return string
     */
    public function setEmployeeId($employee_id);

    public function setEmployeeName($employee_name);

    public function setEmployeeAge($employee_age);

    public function setEmployeePhone($employee_phone);

    public function setEmployeeGender($employee_gender);
}