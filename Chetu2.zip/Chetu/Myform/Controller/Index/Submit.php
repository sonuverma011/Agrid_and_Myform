<?php

namespace Chetu\Myform\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Chetu\Myform\Model\EmpGridFactory;
use Magento\Framework\UrlInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;

class Submit extends Action implements CsrfAwareActionInterface
{
	protected $_pageFactory;

	public function __construct(
        UrlInterface $url,
		Context $context,
        PageFactory $resultPageFactory,
        EmpGridFactory $empgridfactory
    )
	{
		$this->resultPageFactory = $resultPageFactory;
        $this->empgridfactory = $empgridfactory;
        $this->url = $url;
        parent::__construct($context);
	}

	public function execute()
	{
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->url->getUrl('myform/index/showdata'));

        $model = $this->empgridfactory->create();
        $employee_name = $this->getRequest()->getParam('employee_name');
        $employee_age = $this->getRequest()->getParam('employee_age');
        $employee_phone= $this->getRequest()->getParam('employee_phone');
        $employee_gender= $this->getRequest()->getParam('employee_gender');
        if(!empty($employee_name && $employee_phone && $employee_gender)){
            $model->addData([
                "employee_name" => $employee_name,
                "employee_age" => $employee_age,
                "employee_phone" => $employee_phone,
                "employee_gender" => $employee_gender,
                "sort_order" => 1
            ]);
            if(!empty($model)){
                $this->messageManager->addSuccess( __('All Data Fields are Filled') );
            }
            $saveData = $model->save();
            if($saveData){$this->messageManager->addSuccessMessage( __('Insert Record Successfully !') ); }
        }
        else{$this->messageManager->addErrorMessage( __('Form Input Field are Empty !') );}
        
        return $resultRedirect;
    }
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }
 
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

}