<?php

namespace Chetu\Myform\Controller\Adminhtml\Create;

use Magento\Backend\App\Action;
use Magento\Backend\Model\Session;
use \Chetu\Myform\Model\EmpGrid;

class Save extends \Magento\Backend\App\Action
{

    protected $empgrid;
    protected $adminsession;

    public function __construct(Action\Context $context,EmpGrid $empgrid, Session $adminsession) 
    {
        parent::__construct($context);
        $this->empgrid = $empgrid;
        $this->adminsession = $adminsession;
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
            $employee_id = $this->getRequest()->getParam('employee_id');
            if ($employee_id) {
                $this->empgrid->load($employee_id);
            }
            print_r("hello");
            print_r($employee_id);
            die('working');
            $this->formData->setData($data);
            
            try {
                $this->empgrid->save();
                $this->messageManager->addSuccess(__('The data has been saved.'));
                $this->adminsession->setEmpGrid(false);
                return $resultRedirect->setPath('agrid/create/index');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the data.'));
            }
            $this->_getSession()->setEmpGrid($data);
            return $resultRedirect->setPath('*/*/edit', ['employee_id' => $this->getRequest()->getParam('employee_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}