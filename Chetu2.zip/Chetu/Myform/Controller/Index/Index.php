<?php
namespace Chetu\Myform\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{   
		$resultpage = $this->_pageFactory->create();
		$resultpage->getConfig()->getTitle()->set('Custom Form For Admin Grid');
		return $resultpage;
	}
}	