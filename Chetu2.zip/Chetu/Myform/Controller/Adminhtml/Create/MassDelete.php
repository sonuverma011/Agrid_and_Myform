<?php
namespace Chetu\Myform\Controller\Adminhtml\Create;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Chetu\Myform\Model\ResourceModel\EmpGrid\CollectionFactory;
use Chetu\Myform\Model\EmpGridFactory;

class MassDelete extends Action
{
    public $collectionFactory;

    public $filter;

    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        EmpGridFactory $empgridFactory
    ) {
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->empgridFactory = $empgridFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        try {
            $collection = $this->filter->getCollection($this->collectionFactory->create());

            $count = 0;
            foreach ($collection as $record) {
                $record = $this->empgridFactory->create()->load($record->getEmployeeId());
                $record->delete();
                $count++;
            }
            $this->messageManager->addSuccess(__('A total of %1 record(s) have been deleted.', $count));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('agrid/create/index');
    }

    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Chetu_Myform::delete');
    }
}