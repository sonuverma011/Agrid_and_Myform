<?php
namespace Chetu\Myform\Controller\Adminhtml\Create;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Chetu\Myform\Model\EmpGridFactory;

class Delete extends Action
{
    public $empgridFactory;
    
    public function __construct(
        Context $context,
        EmpGridFactory $empgridFactory
    ) {
        $this->empgridFactory = $empgridFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $employee_id = $this->getRequest()->getParam('id');
        
        if($employee_id){
            try {
                $model = $this->empgridFactory->create();
                $model->load($employee_id);
                $model->delete();
                $this->messageManager->addSuccessMessage(__('You Successfully Deleted the Employee Record'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['id' => $employee_id]);
            }
        }
        else{$this->messageManager->addErrorMessage(__('We can\'t find a employee record to delete.'));}
        return $resultRedirect->setPath('*/*/');
    }

    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Chetu_Myform::delete');
    }
}