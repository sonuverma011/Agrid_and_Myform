<?php

namespace Chetu\Myform\Controller\Adminhtml\Create;

class Save extends \Magento\Backend\App\Action
{
    var $empGridFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Chetu\Myform\Model\EmpGridFactory $empGridFactory
    ) {
        parent::__construct($context);
        $this->empGridFactory = $empGridFactory;
    }

    public function execute()
    {
        $empid = $_SESSION["emp_id"];
        
        $data = $this->getRequest()->getPostValue();
        
        if (!$data) {
            $this->_redirect('agrid/create/addemployee');
            return;
        }
        try {
            $empData = $this->empGridFactory->create();
            $empData->setData($data);
            if (isset($empid)) {
                $empData->setEmployeeId($empid);
            }
            $empData->save();
            $this->messageManager->addSuccess(__('Employee data has been successfully updated.'));
        }catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('agrid/create/index');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Chetu_Myform::save');
    }
}




