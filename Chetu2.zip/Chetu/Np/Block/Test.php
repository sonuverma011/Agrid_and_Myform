<?php
namespace Chetu\Np\Block;
 
use Magento\Backend\Block\Template\Context;
use Magento\Framework\View\Element\Template;
use Chetu\Np\Model\DataSampleFactory;

class Test extends \Magento\Framework\View\Element\Template
{
    private $datasampleFactory;
 
    public function __construct(DataSampleFactory $datasampleFactory, Context $context, \Magento\Framework\Data\Form\FormKey $formKey,array $data = [])
    {
        parent::__construct($context, $data);
        $this->formKey = $formKey;
        $this->datasampleFactory = $datasampleFactory;
    }
 
    // public function getFormAction()
    // {
    //     return $this->getUrl('uiform/index/result', ['_secure' => true]);
    // }
    public function getFormKey()
    {
         return $this->formKey->getFormKey();
    }
    
}
