<?php
namespace Chetu\Np\Controller\Index;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;

class Test extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Store\Model\StoreManagerInterface $storeManager)// \Magento\Framework\App\ResourceConnection $resource,
	{
		$this->_pageFactory = $pageFactory;
		$this->_storeManager = $storeManager;
		return parent::__construct($context);
	}
	// $this->_resource = $resource; // for creating object in constructor

	public function execute()
	{   
		$resultpage = $this->_pageFactory->create();
		$resultpage->getConfig()->getTitle()->set('Custom Page');
		return $resultpage;
	}
	public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }
 
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }
}	