<?php
namespace Chetu\Np\Controller\Index;

class UiForm extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Chetu\Np\Model\FormFactory $formFactory)
	{
		$this->_pageFactory = $pageFactory;
		$this->_formFactory = $formFactory;
		return parent::__construct($context);
	}

	public function execute()
	{	
		$resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend(__('Manage Grid'));
        return $resultPage;
		
	}
}