<?php
namespace Chetu\Np\Model\ResourceModel\EmpGrid;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected function _construct()
	{
		$this->_init('Chetu\Np\Model\EmpGrid', 'Chetu\Np\Model\ResourceModel\EmpGrid');
	}
}