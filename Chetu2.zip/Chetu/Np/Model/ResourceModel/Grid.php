<?php

namespace Chetu\Np\Model\ResourceModel;

use Magento\Catalog\Model\ResourceModel\Category as BaseCategory;

class Grid extends BaseCategory
{
}