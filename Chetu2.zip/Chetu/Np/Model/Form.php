<?php
namespace Chetu\Np\Model;
class Form extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'ui_comp_form';
	protected $_cacheTag = 'ui_comp_form';
	protected $_eventPrefix = 'ui_comp_form';

	protected function _construct()
	{
		$this->_init('Chetu\Np\Model\ResourceModel\Form');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}
    
	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}