<?php
namespace Chetu\NP\Model;
class EmpGrid extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'custom_grid';

	protected $_cacheTag = 'custom_grid';

	protected $_eventPrefix = 'custom_grid';

	protected function _construct()
	{
		$this->_init('Chetu\Np\Model\ResourceModel\EmpGrid');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}